import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

// ==========================================
// HARDCODED SUPABASE CONFIGURATION
// ==========================================
const SUPABASE_URL = "https://itdlszsqnjhjgqwjvjrd.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml0ZGxzenNxbmpoamdxd2p2anJkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQyNjYxOTEsImV4cCI6MjA5OTg0MjE5MX0.rxSY6ReprTVXn2Sa5ds8go5QazLsniZcVMMkvtA6eOU";

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const FILTERS = [
  { label: 'Normal', value: 'none' },
  { label: 'B&W', value: 'grayscale(100%)' },
  { label: 'Sepia', value: 'sepia(80%)' },
  { label: 'Vintage', value: 'contrast(1.2) saturate(1.4) sepia(0.3)' }
];

export default function Gallery({ sessionId }) {
  const [images, setImages] = useState([]);
  const [activeFilter, setActiveFilter] = useState('none');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchImages() {
      try {
        // 1. List files inside the session's folder in Supabase Storage
        const { data, error } = await supabase
          .storage
          .from('pibooth')
          .list(sessionId, {
            sortBy: { column: 'name', order: 'asc' }
          });

        if (error) {
          throw error;
        }

        // 2. Generate public URLs for each file found
        if (data && data.length > 0) {
          const validFiles = data.filter(file => file.name.endsWith('.jpg'));
          
          const photoUrls = validFiles.map((file) => {
            const { data: publicUrlData } = supabase
              .storage
              .from('pibooth')
              .getPublicUrl(`${sessionId}/${file.name}`);
            return publicUrlData.publicUrl;
          });

          setImages(photoUrls);
        }
      } catch (error) {
        console.error("Failed to load gallery from Supabase:", error);
      } finally {
        setLoading(false);
      }
    }

    if (sessionId) {
      fetchImages();
    }
  }, [sessionId]);

  const sprockets = Array.from({ length: 14 }).map((_, i) => (
    <span key={i} className="w-[9px] h-[9px] rounded-[2px] bg-[#15130f]"></span>
  ));

  const downloadSingle = async (imgSrc, index) => {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous'; // Crucial for canvas operations
      img.src = imgSrc;
      await new Promise(resolve => { img.onload = resolve; });

      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      
      ctx.filter = activeFilter;
      ctx.drawImage(img, 0, 0);
      
      const link = document.createElement('a');
      link.download = `pibooth_photo_${index + 1}.jpg`;
      link.href = canvas.toDataURL('image/jpeg', 0.95);
      link.click();
    } catch (err) {
      console.error("Failed to download image", err);
    }
  };

  const downloadCollage = async () => {
    if (images.length === 0) return;
    
    const loadedImages = await Promise.all(images.map(src => {
      return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.src = src;
      });
    }));

    const w = loadedImages[0].naturalWidth;
    const h = loadedImages[0].naturalHeight;
    const padding = 40;

    const canvas = document.createElement('canvas');
    canvas.width = w + (padding * 2);
    canvas.height = (h * loadedImages.length) + (padding * (loadedImages.length + 1));
    const ctx = canvas.getContext('2d');

    // Solid black film strip background
    ctx.fillStyle = '#0a0908';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.filter = activeFilter;

    loadedImages.forEach((img, i) => {
      const y = padding + i * (h + padding);
      ctx.drawImage(img, padding, y, w, h);
    });

    const link = document.createElement('a');
    link.download = `pibooth_strip_${sessionId}.jpg`;
    link.href = canvas.toDataURL('image/jpeg', 0.95);
    link.click();
  };

  if (loading) return <div className="min-h-screen bg-[#15130f] text-[#f4ede2] flex items-center justify-center font-mono">Developing...</div>;
  
  if (images.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center bg-[#15130f] text-[#f4ede2]">
        <h1 className="font-serif italic font-normal text-[#ff5a2e] text-3xl">Roll Not Found</h1>
        <p className="font-mono mt-2">This strip has expired or never existed.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#15130f] bg-[radial-gradient(ellipse_at_top,rgba(255,90,46,0.08),transparent_60%)] text-[#f4ede2] font-mono antialiased selection:bg-[#ff5a2e] selection:text-black">
      <style>{`
        @keyframes develop {
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div className="max-w-[460px] mx-auto pt-7 px-4 pb-16">
        
        {/* Masthead */}
        <div className="text-center mb-6">
          <span className="inline-block tracking-[0.35em] text-[0.65rem] text-[#ff5a2e] uppercase border border-[#a33d1e] rounded-full px-3.5 py-1.5 mb-3.5">
            Roll Developed
          </span>
          <h1 className="font-serif italic font-normal text-3xl m-0 mb-1.5 tracking-wide">
            Your Strip
          </h1>
          <p className="m-0 text-[#b8ab9a] text-[0.82rem]">
            Pick a filter before downloading.
          </p>
        </div>

        {/* Filters */}
        <div className="flex gap-2 justify-center mb-6 flex-wrap">
          {FILTERS.map((f) => (
            <button
              key={f.label}
              onClick={() => setActiveFilter(f.value)}
              className={`bg-[#1d1a15] px-3.5 py-1.5 rounded-full cursor-pointer text-xs transition-all duration-200 border 
                ${activeFilter === f.value 
                  ? 'bg-[#ff5a2e] text-[#15130f] border-[#ff5a2e] font-bold' 
                  : 'text-[#f4ede2] border-[#b8ab9a] hover:border-[#ff5a2e]'}`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Collage Download */}
        <div className="flex justify-center mb-5">
          <button 
            onClick={downloadCollage}
            className="bg-[#ff5a2e] text-[#15130f] px-6 py-3 rounded-md font-black cursor-pointer uppercase tracking-[0.1em] transition-transform duration-100 active:scale-95 active:bg-[#ff7a52] w-full"
          >
            Download Full Strip
          </button>
        </div>

        {/* The Film Strip */}
        <div className="bg-[#0a0908] rounded-2xl py-1 shadow-[0_20px_45px_rgba(0,0,0,0.55)]">
          
          <div className="flex justify-between px-3.5 py-1">{sprockets}</div>
          
          <div className="p-3.5 flex flex-col gap-3.5">
            {images.map((src, index) => (
              <figure 
                key={index} 
                className="m-0 relative bg-[#1d1a15] p-2.5 pb-3.5 rounded-md opacity-0 translate-y-2.5 animate-[develop_0.6s_ease-out_forwards]"
                style={{ animationDelay: `${index * 120}ms` }}
              >
                <img 
                  src={src} 
                  alt={`Photo ${index + 1}`} 
                  style={{ filter: activeFilter }} 
                  crossOrigin="anonymous" 
                  className="block w-full rounded-sm transition-all duration-300"
                />
                
                <button 
                  onClick={() => downloadSingle(src, index)}
                  className="flex items-center justify-center gap-2 mt-2.5 text-[#15130f] bg-[#ff5a2e] font-bold text-[0.78rem] tracking-[0.12em] uppercase py-2.5 rounded transition-all duration-150 w-full cursor-pointer active:scale-95 active:bg-[#ff7a52]"
                >
                  Save
                </button>
              </figure>
            ))}
          </div>

          <div className="flex justify-between px-3.5 py-1">{sprockets}</div>
        </div>

        {/* Hint */}
        <p className="text-center text-[#b8ab9a] text-[0.75rem] mt-6 leading-relaxed">
          Photos are securely backed up to the cloud.<br />
          <strong className="text-[#f4ede2]">Save them or bookmark this link!</strong>
        </p>
      </div>
    </div>
  );
}












// import { useState, useEffect } from 'react';

// const SERVER_IP = "192.168.100.75";
// const FILTERS = [
//   { label: 'Normal', value: 'none' },
//   { label: 'B&W', value: 'grayscale(100%)' },
//   { label: 'Sepia', value: 'sepia(80%)' },
//   { label: 'Vintage', value: 'contrast(1.2) saturate(1.4) sepia(0.3)' }
// ];

// export default function Gallery({ sessionId }) {
//   const [images, setImages] = useState([]);
//   const [activeFilter, setActiveFilter] = useState('none');
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     async function fetchImages() {
//       try {
//         const response = await fetch(`http://${SERVER_IP}:8000/api/gallery/${sessionId}`);
//         const data = await response.json();
//         if (data.images) {
//           setImages(data.images);
//         }
//       } catch (error) {
//         console.error("Failed to load gallery:", error);
//       } finally {
//         setLoading(false);
//       }
//     }
//     fetchImages();
//   }, [sessionId]);

//   const sprockets = Array.from({ length: 14 }).map((_, i) => (
//     <span key={i} className="w-[9px] h-[9px] rounded-[2px] bg-[#15130f]"></span>
//   ));

//   const downloadSingle = async (imgSrc, index) => {
//     try {
//       const img = new Image();
//       img.crossOrigin = 'anonymous';
//       img.src = imgSrc;
//       await new Promise(resolve => { img.onload = resolve; });

//       const canvas = document.createElement('canvas');
//       canvas.width = img.naturalWidth;
//       canvas.height = img.naturalHeight;
//       const ctx = canvas.getContext('2d');
      
//       ctx.filter = activeFilter;
//       ctx.drawImage(img, 0, 0);
      
//       const link = document.createElement('a');
//       link.download = `pibooth_photo_${index + 1}.jpg`;
//       link.href = canvas.toDataURL('image/jpeg', 0.95);
//       link.click();
//     } catch (err) {
//       console.error("Failed to download image", err);
//     }
//   };

//   const downloadCollage = async () => {
//     if (images.length === 0) return;
    
//     const loadedImages = await Promise.all(images.map(src => {
//       return new Promise((resolve) => {
//         const img = new Image();
//         img.crossOrigin = 'anonymous';
//         img.onload = () => resolve(img);
//         img.src = src;
//       });
//     }));

//     const w = loadedImages[0].naturalWidth;
//     const h = loadedImages[0].naturalHeight;
//     const padding = 40;

//     const canvas = document.createElement('canvas');
//     canvas.width = w + (padding * 2);
//     canvas.height = (h * loadedImages.length) + (padding * (loadedImages.length + 1));
//     const ctx = canvas.getContext('2d');

//     // Solid black film strip background
//     ctx.fillStyle = '#0a0908';
//     ctx.fillRect(0, 0, canvas.width, canvas.height);
//     ctx.filter = activeFilter;

//     loadedImages.forEach((img, i) => {
//       const y = padding + i * (h + padding);
//       ctx.drawImage(img, padding, y, w, h);
//     });

//     const link = document.createElement('a');
//     link.download = `pibooth_strip_${sessionId}.jpg`;
//     link.href = canvas.toDataURL('image/jpeg', 0.95);
//     link.click();
//   };

//   if (loading) return <div className="min-h-screen bg-[#15130f] text-[#f4ede2] flex items-center justify-center font-mono">Developing...</div>;
  
//   if (images.length === 0) {
//     return (
//       <div className="min-h-screen flex flex-col items-center justify-center text-center bg-[#15130f] text-[#f4ede2]">
//         <h1 className="font-serif italic font-normal text-[#ff5a2e] text-3xl">Roll Not Found</h1>
//         <p className="font-mono mt-2">This strip has expired or never existed.</p>
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen bg-[#15130f] bg-[radial-gradient(ellipse_at_top,rgba(255,90,46,0.08),transparent_60%)] text-[#f4ede2] font-mono antialiased selection:bg-[#ff5a2e] selection:text-black">
//       {/* We inject one small style block solely for the custom CSS animation keyframe */}
//       <style>{`
//         @keyframes develop {
//           to { opacity: 1; transform: translateY(0); }
//         }
//       `}</style>

//       <div className="max-w-[460px] mx-auto pt-7 px-4 pb-16">
        
//         {/* Masthead */}
//         <div className="text-center mb-6">
//           <span className="inline-block tracking-[0.35em] text-[0.65rem] text-[#ff5a2e] uppercase border border-[#a33d1e] rounded-full px-3.5 py-1.5 mb-3.5">
//             Roll Developed
//           </span>
//           <h1 className="font-serif italic font-normal text-3xl m-0 mb-1.5 tracking-wide">
//             Your Strip
//           </h1>
//           <p className="m-0 text-[#b8ab9a] text-[0.82rem]">
//             Pick a filter before downloading.
//           </p>
//         </div>

//         {/* Filters */}
//         <div className="flex gap-2 justify-center mb-6 flex-wrap">
//           {FILTERS.map((f) => (
//             <button
//               key={f.label}
//               onClick={() => setActiveFilter(f.value)}
//               className={`bg-[#1d1a15] px-3.5 py-1.5 rounded-full cursor-pointer text-xs transition-all duration-200 border 
//                 ${activeFilter === f.value 
//                   ? 'bg-[#ff5a2e] text-[#15130f] border-[#ff5a2e] font-bold' 
//                   : 'text-[#f4ede2] border-[#b8ab9a] hover:border-[#ff5a2e]'}`}
//             >
//               {f.label}
//             </button>
//           ))}
//         </div>

//         {/* Collage Download */}
//         <div className="flex justify-center mb-5">
//           <button 
//             onClick={downloadCollage}
//             className="bg-[#ff5a2e] text-[#15130f] px-6 py-3 rounded-md font-black cursor-pointer uppercase tracking-[0.1em] transition-transform duration-100 active:scale-95 active:bg-[#ff7a52] w-full"
//           >
//             Download Full Strip
//           </button>
//         </div>

//         {/* The Film Strip */}
//         <div className="bg-[#0a0908] rounded-2xl py-1 shadow-[0_20px_45px_rgba(0,0,0,0.55)]">
          
//           <div className="flex justify-between px-3.5 py-1">{sprockets}</div>
          
//           <div className="p-3.5 flex flex-col gap-3.5">
//             {images.map((src, index) => (
//               <figure 
//                 key={index} 
//                 className="m-0 relative bg-[#1d1a15] p-2.5 pb-3.5 rounded-md opacity-0 translate-y-2.5 animate-[develop_0.6s_ease-out_forwards]"
//                 style={{ animationDelay: `${index * 120}ms` }}
//               >
//                 <img 
//                   src={src} 
//                   alt={`Photo ${index + 1}`} 
//                   style={{ filter: activeFilter }} 
//                   crossOrigin="anonymous" 
//                   className="block w-full rounded-sm transition-all duration-300"
//                 />
                
//                 <button 
//                   onClick={() => downloadSingle(src, index)}
//                   className="flex items-center justify-center gap-2 mt-2.5 text-[#15130f] bg-[#ff5a2e] font-bold text-[0.78rem] tracking-[0.12em] uppercase py-2.5 rounded transition-all duration-150 w-full cursor-pointer active:scale-95 active:bg-[#ff7a52]"
//                 >
//                   Save
//                 </button>
//               </figure>
//             ))}
//           </div>

//           <div className="flex justify-between px-3.5 py-1">{sprockets}</div>
//         </div>

//         {/* Hint */}
//         <p className="text-center text-[#b8ab9a] text-[0.75rem] mt-6 leading-relaxed">
//           Photos live on this device's local network only.<br />
//           <strong className="text-[#f4ede2]">This link expires when the booth resets.</strong>
//         </p>
//       </div>
//     </div>
//   );
// }