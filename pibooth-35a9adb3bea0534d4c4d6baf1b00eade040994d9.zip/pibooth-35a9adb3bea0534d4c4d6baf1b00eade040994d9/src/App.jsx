import { useState, useEffect } from 'react';
import QRCode from 'react-qr-code';
import Gallery from './Gallery';

// 1. KEEP this as your Pi's IP. The hardware camera feed and WebSocket 
// state machine still run locally on the Pi.
const SERVER_IP = "192.168.100.75"; 

// 2. PASTE YOUR VERCEL URL HERE (e.g., https://pibooth-nine.vercel.app)
// This ensures your local screen generates a QR code pointing to the public internet!
const VERCEL_URL = "https://pibooth.vercel.app";

function BoothUI() {
  const [boothState, setBoothState] = useState({
    status: "WAITING",
    capture_count: 0,
    remaining_time: 0,
    session_id: null
  });

  useEffect(() => {
    const ws = new WebSocket(`ws://${SERVER_IP}:8000/ws`);
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setBoothState(data);
    };
    return () => ws.close();
  }, []);

  const fireTestTrigger = async () => {
    try {
      await fetch(`http://${SERVER_IP}:8000/test-trigger`);
    } catch (error) {
      console.error("Failed to hit test trigger:", error);
    }
  };

  // Generates the link pointing to your Vercel site for mobile scanning
  const galleryUrl = boothState.session_id 
    ? `${VERCEL_URL}/gallery/${boothState.session_id}`
    : '';

  return (
    <div className="relative w-screen h-screen bg-[#15130f] overflow-hidden selection:bg-[#ff5a2e] selection:text-black">
      
      {/* 1. Video Feed (Still pulls directly from Pi hardware) */}
      <img 
        src={`http://${SERVER_IP}:8000/video_feed`} 
        className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]"
        alt="Live Camera Feed"
      />

      {/* 2. Vignette Overlay (Darkens edges to simulate an old camera lens) */}
      <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_150px_rgba(10,9,8,0.85)] z-10" />

      {/* 3. Dev Tools & Branding */}
      <div className="absolute top-8 left-8 flex items-center gap-6 z-50">
        <div className="text-[#f4ede2] font-serif italic text-3xl tracking-wide drop-shadow-lg flex items-center gap-3">
          <span className="w-3 h-3 rounded-full bg-[#ff5a2e] shadow-[0_0_10px_rgba(255,90,46,0.8)] animate-pulse"></span>
          PiBooth
        </div>
        <button 
          onClick={fireTestTrigger}
          className="px-4 py-2 bg-[#ff5a2e] hover:bg-[#ff7a52] text-[#15130f] font-mono text-xs font-black rounded shadow transition-transform active:scale-95 cursor-pointer uppercase tracking-widest border-none"
        >
          Force Trigger
        </button>
      </div>

      {/* 4. Film Frame Tracker (Top Right) */}
      <div className="absolute top-10 right-10 flex gap-3 z-50">
        {[0, 1, 2, 3].map((frameIndex) => (
          <div 
            key={frameIndex} 
            className={`w-3.5 h-3.5 rounded-sm transform rotate-45 transition-all duration-300 ${
              boothState.capture_count > frameIndex 
                ? 'bg-[#ff5a2e] shadow-[0_0_12px_rgba(255,90,46,0.6)]' 
                : 'bg-transparent border border-[#b8ab9a]/50'
            }`} 
          />
        ))}
      </div>

      {/* State: WAITING */}
      {boothState.status === "WAITING" && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 transition-opacity duration-500 z-50">
          <div className="px-8 py-4 rounded-full bg-[#1d1a15]/80 backdrop-blur-md border border-[#b8ab9a]/30 shadow-2xl flex items-center gap-4">
            <span className="text-[#f4ede2] font-mono text-lg tracking-widest uppercase opacity-90 drop-shadow-md">
              Show an open palm to start
            </span>
          </div>
        </div>
      )}

      {/* State: COUNTDOWN */}
      {boothState.status === "COUNTDOWN" && (
        <div className="absolute inset-0 flex items-center justify-center z-50">
          <div className="relative flex items-center justify-center w-64 h-64 rounded-full border border-[#b8ab9a]/20 bg-[#1d1a15]/40 backdrop-blur-sm">
            <div className="absolute inset-0 rounded-full border-8 border-[#ff5a2e] shadow-[0_0_40px_rgba(255,90,46,0.5)] animate-pulse" />
            <span className="text-[#f4ede2] text-9xl font-serif italic drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
              {Math.ceil(boothState.remaining_time)}
            </span>
          </div>
        </div>
      )}

      {/* State: CAPTURING (Camera Flash) */}
      {boothState.status === "CAPTURING" && (
        <div className="absolute inset-0 bg-white z-[100] animate-[ping_0.5s_cubic-bezier(0,0,0.2,1)_1]" />
      )}

      {/* State: SHOW_QR */}
      {boothState.status === "SHOW_QR" && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-[#15130f]/80 backdrop-blur-md transition-all duration-500">
          <div className="bg-[#1d1a15] border border-[#b8ab9a]/30 p-10 rounded-2xl shadow-2xl flex flex-col items-center">
            
            <h2 className="text-[#ff5a2e] font-serif italic text-4xl mb-2 drop-shadow-md">
              Scan to Save
            </h2>
            
            <p className="text-[#b8ab9a] font-mono text-sm mb-8 tracking-widest uppercase">
              Resets in {Math.ceil(boothState.remaining_time)}s
            </p>

            <div className="bg-[#f4ede2] p-4 rounded-xl shadow-inner">
              <QRCode
                value={galleryUrl} // Uses the dynamic Vercel URL!
                size={220}
                bgColor="#f4ede2"
                fgColor="#15130f"
                level="Q"
              />
            </div>
            
          </div>
        </div>
      )}

    </div>
  );
}

export default function App() {
  const path = window.location.pathname;

  // Simple router: If URL is /gallery/UUID, show the gallery
  if (path.startsWith('/gallery/')) {
    const sessionId = path.split('/')[2];
    return <Gallery sessionId={sessionId} />;
  }

  // Otherwise, show the photobooth
  return <BoothUI />;
}














// import { useState, useEffect } from 'react';
// import QRCode from 'react-qr-code';
// import Gallery from './Gallery';

// // Change this to your Pi's actual IP
// const SERVER_IP = "192.168.100.75"; 

// function BoothUI() {
//   const [boothState, setBoothState] = useState({
//     status: "WAITING",
//     capture_count: 0,
//     remaining_time: 0,
//     session_id: null
//   });

//   useEffect(() => {
//     const ws = new WebSocket(`ws://${SERVER_IP}:8000/ws`);
//     ws.onmessage = (event) => {
//       const data = JSON.parse(event.data);
//       setBoothState(data);
//     };
//     return () => ws.close();
//   }, []);

//   const fireTestTrigger = async () => {
//     try {
//       await fetch(`http://${SERVER_IP}:8000/test-trigger`);
//     } catch (error) {
//       console.error("Failed to hit test trigger:", error);
//     }
//   };

//   return (
//     <div className="relative w-screen h-screen bg-[#15130f] overflow-hidden selection:bg-[#ff5a2e] selection:text-black">
      
//       {/* 1. Video Feed */}
//       <img 
//         src={`http://${SERVER_IP}:8000/video_feed`} 
//         className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]"
//         alt="Live Camera Feed"
//       />

//       {/* 2. Vignette Overlay (Darkens edges to simulate an old camera lens) */}
//       <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_150px_rgba(10,9,8,0.85)] z-10" />

//       {/* 3. Dev Tools & Branding */}
//       <div className="absolute top-8 left-8 flex items-center gap-6 z-50">
//         <div className="text-[#f4ede2] font-serif italic text-3xl tracking-wide drop-shadow-lg flex items-center gap-3">
//           <span className="w-3 h-3 rounded-full bg-[#ff5a2e] shadow-[0_0_10px_rgba(255,90,46,0.8)] animate-pulse"></span>
//           PiBooth
//         </div>
//         <button 
//           onClick={fireTestTrigger}
//           className="px-4 py-2 bg-[#ff5a2e] hover:bg-[#ff7a52] text-[#15130f] font-mono text-xs font-black rounded shadow transition-transform active:scale-95 cursor-pointer uppercase tracking-widest border-none"
//         >
//           Force Trigger
//         </button>
//       </div>

//       {/* 4. Film Frame Tracker (Top Right) */}
//       <div className="absolute top-10 right-10 flex gap-3 z-50">
//         {[0, 1, 2, 3].map((frameIndex) => (
//           <div 
//             key={frameIndex} 
//             className={`w-3.5 h-3.5 rounded-sm transform rotate-45 transition-all duration-300 ${
//               boothState.capture_count > frameIndex 
//                 ? 'bg-[#ff5a2e] shadow-[0_0_12px_rgba(255,90,46,0.6)]' 
//                 : 'bg-transparent border border-[#b8ab9a]/50'
//             }`} 
//           />
//         ))}
//       </div>

//       {/* State: WAITING */}
//       {boothState.status === "WAITING" && (
//         <div className="absolute bottom-16 left-1/2 -translate-x-1/2 transition-opacity duration-500 z-50">
//           <div className="px-8 py-4 rounded-full bg-[#1d1a15]/80 backdrop-blur-md border border-[#b8ab9a]/30 shadow-2xl flex items-center gap-4">
//             <span className="text-[#f4ede2] font-mono text-lg tracking-widest uppercase opacity-90 drop-shadow-md">
//               Show an open palm to start
//             </span>
//           </div>
//         </div>
//       )}

//       {/* State: COUNTDOWN */}
//       {boothState.status === "COUNTDOWN" && (
//         <div className="absolute inset-0 flex items-center justify-center z-50">
//           <div className="relative flex items-center justify-center w-64 h-64 rounded-full border border-[#b8ab9a]/20 bg-[#1d1a15]/40 backdrop-blur-sm">
//             {/* Pulsing Safelight Ring */}
//             <div className="absolute inset-0 rounded-full border-8 border-[#ff5a2e] shadow-[0_0_40px_rgba(255,90,46,0.5)] animate-pulse" />
//             <span className="text-[#f4ede2] text-9xl font-serif italic drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
//               {Math.ceil(boothState.remaining_time)}
//             </span>
//           </div>
//         </div>
//       )}

//       {/* State: CAPTURING (Camera Flash) */}
//       {boothState.status === "CAPTURING" && (
//         <div className="absolute inset-0 bg-white z-[100] animate-[ping_0.5s_cubic-bezier(0,0,0.2,1)_1]" />
//       )}

//       {/* State: SHOW_QR */}
//       {boothState.status === "SHOW_QR" && (
//         <div className="absolute inset-0 flex items-center justify-center z-50 bg-[#15130f]/80 backdrop-blur-md transition-all duration-500">
//           <div className="bg-[#1d1a15] border border-[#b8ab9a]/30 p-10 rounded-2xl shadow-2xl flex flex-col items-center">
            
//             <h2 className="text-[#ff5a2e] font-serif italic text-4xl mb-2 drop-shadow-md">
//               Scan to Save
//             </h2>
            
//             <p className="text-[#b8ab9a] font-mono text-sm mb-8 tracking-widest uppercase">
//               Resets in {Math.ceil(boothState.remaining_time)}s
//             </p>

//             <div className="bg-[#f4ede2] p-4 rounded-xl shadow-inner">
//               <QRCode
//                 value={`http://${SERVER_IP}:5173/gallery/${boothState.session_id}`}
//                 size={220}
//                 bgColor="#f4ede2"
//                 fgColor="#15130f"
//                 level="Q"
//               />
//             </div>
            
//           </div>
//         </div>
//       )}

//     </div>
//   );
// }

// export default function App() {
//   const path = window.location.pathname;

//   // Simple router: If URL is /gallery/UUID, show the gallery
//   if (path.startsWith('/gallery/')) {
//     const sessionId = path.split('/')[2];
//     return <Gallery sessionId={sessionId} />;
//   }

//   // Otherwise, show the photobooth
//   return <BoothUI />;
// }